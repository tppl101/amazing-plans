<!DOCTYPE html>

<html>

<head>
	<meta charset="utf-8" />
	<link rel="shortcut icon" href="images/logo.png" type="image/x-icon" />
	<title>Amazing Plans</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<link rel="stylesheet" href="styles/style.css" />
	<link rel="stylesheet" href="styles/signup.css" />
</head>

<body background="images/background.jpg" style="background-size: cover;">
	<div class="center">
		<div class="logo">
			<img src="images/logo.png" alt="Amazing Plans" />
			<h1>Amazing Plans</h1>
			<p><i>Plans and Routes</i></p>
		</div>
		<div class="account">

			<?php if (isset($_GET['error'])) { ?>
				<p style="color: white; background-color: #e60000; border-radius: 3px; text-align: center; padding: 5px;">
					<?php echo $_GET['error']; ?>
				</p>
				<br>
			<?php } ?>

			<form action="data_en.php" method="post">
				<div class="parallel">
					<div class="size">
						<label><b>First Name<font style="color: #994d00">*</font></b></label>
						<input type="text" id="fname" name="fname" placeholder="Enter your first name">
					</div>
					<div class="size">
						<label><b>Last Name<font style="color: #994d00">*</font></b></label>
						<input type="text" id="lname" name="lname" placeholder="Enter your last name">
					</div>
				</div>
				<div class="parallel">
					<div class="size" style="margin-top: 5px">
						<label><b>Email<font style="color: #994d00">*</font></b></label>
						<input type="email" id="email" name="email" placeholder="Enter your email">
					</div>
					<div class="size" style="margin-top: 5px">
						<label><b>Password<font style="color: #994d00">*</font></b></label>
						<input type="password" id="password" name="password" placeholder="Enter your password">
					</div>
				</div>
				<div class="parallel">
					<div class="size" style="margin-top: 5px">
						<label><b>Birth<font style="color: #994d00">*</font></b></label>
						<input type="date" id="birth" name="birth">
					</div>
					<div class="size" style="margin-top: 5px">
						<label><b>City</b></label>
						<input type="text" id="city" name="city" placeholder="Enter your city" />
					</div>
				</div>
				<div class="parallel">
					<div class="size" style="margin-top: 5px">
						<label><b>State</b></label>
						<input type="text" id="state" name="state" placeholder="Enter your state" />
					</div>
					<div class="size" style="margin-top: 5px">
						<label><b>Country</b></label>
						<input type="text" id="country" name="country" placeholder="Enter your country" />
					</div>
				</div>
				<div class="check">
					<input type="checkbox" id="check" name="check" value="check">
					<p>I have read and agree to the app's terms of service and privacy.<font style="color: #994d00">*</font>
					</p>
				</div>
				<div class="div">
					<a href="index_en.php">
						<p>Already have an account? Login</p>
					</a>
					<input type="submit" value="Sign up" />
				</div>
			</form>
		</div>
	</div>
</body>

</html>