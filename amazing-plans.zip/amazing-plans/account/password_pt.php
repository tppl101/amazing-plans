<!DOCTYPE html>

<?php
session_start();
?>

<html lang="pt">

<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
	<title>Amazing Plans</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="styles/style.css">
	<link rel="stylesheet" href="styles/button.css">
	<link rel="stylesheet" href="styles/con-box.css">
</head>

<body>

	<!-- Container -->
	<div class="container">

		<!-- Map Boxs -->
		<div class="con-box">

			<?php if (isset($_GET['error'])) { ?>
				<p style="color: white; background-color: #e60000; border-radius: 3px; text-align: center; padding: 5px; width: 182px">
					<?php echo $_GET['error']; ?>
				</p>
				<br>
			<?php } ?>

			<form action="update_pwrd.php" method="post">
				<div>
					<div class="label">
						<label><b>Velha senha</b></label>
					</div>
					<input type="password" id="opassword" name="opassword" placeholder="Digite sua senha">
				</div>
				<br>
				<div>
					<div class="label">
						<label><b>Nova senha</b></label>
					</div>
					<input type="password" id="password" name="password" placeholder="Digite sua senha">
				</div>
				<br>
				<div>
					<input type="submit" value="Salvar" />
				</div>
			</form>
			<br>
			<!--button onclick="closeCurrentTab()">Cancelar</button-->
			<a href="profile_pt.php"><button onclick="closeCurrentTab()">Cancelar</button></a>
		</div>

	</div>

	<!--script>
		function closeCurrentTab() {
    		window.close();
		}
	</script-->

</body>

</html>