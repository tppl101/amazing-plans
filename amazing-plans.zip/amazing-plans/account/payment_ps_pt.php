<!DOCTYPE html>

<?php
session_start();

include("../connection.php");
error_reporting(0);

?>

<html lang="pt">

<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
	<title>Amazing Plans</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="styles/style.css">
	<link rel="stylesheet" href="styles/button.css">
	<link rel="stylesheet" href="styles/con-box.css">
</head>

<body>

	<!-- Container -->
	<div class="container">

		<!-- Map Boxs -->
		<div class="con-box">

			<!--button onclick="closeCurrentTab()">Cancelar</button-->
            <a href="ps.php"><button>PayPal</button></a>
            <br><br>
			<a href="ps.php"><button>Pix</button></a>
			<br><br>
			<a href="ps.php"><button>Boleto</button></a>
            <br><br>
			<a href="card_pt.php"><button>Cancelar</button></a>
		</div>

	</div>
</body>

</html>