<!DOCTYPE html>
<html>
<head>
    <title>My Route</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
</head>
<body>
    <div id="map" style="height: 400px;"></div>
    <script>
        var map = L.map('map').setView([40.7128, -74.0060], 13);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
        }).addTo(map);

        // Add route points to the map
        L.marker([40.7128, -74.0060]).addTo(map)
            .bindPopup('My Route Point 1').openPopup();
    </script>
</body>
</html>