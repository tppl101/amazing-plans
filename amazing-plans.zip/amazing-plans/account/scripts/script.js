function redirectToPage() {
    var selectedLanguage = document.getElementById("idioma").value;
    var redirectUrl;

    switch (selectedLanguage) {
    case "pt":
        redirectUrl = "language/portuguese/index.html";
        break;
    case "en":
        redirectUrl = "language/english/index.html";
        break;
    case "sp":
        redirectUrl = "language/spanish/index.html";
        break;
    default:
        redirectUrl = "index.html";
    }

    window.location.href = redirectUrl;
}
