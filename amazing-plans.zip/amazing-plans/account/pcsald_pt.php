<!DOCTYPE html>

<?php
session_start();

include("../connection.php");
error_reporting(0);

$user_id = $_SESSION['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $point = $_POST['point'];
    $cumpon = $_POST['cumpon'];
	$sald = $_POST['sald'];

    if (empty($point) || empty($cumpon) || empty($sald)) {
        header("Location: pcsald_pt.php?error=Todos os campos são obrigatórios.");
        exit();
    }

    $query = "INSERT INTO pcsald (point, cumpon, sald, user_id) VALUES ('$point', '$cumpon', '$sald', $user_id)";
    $result = mysqli_query($conn, $query);

    if($result){
        header("Location: card_pt.php?success=Atualizar corretamente.");
        exit();
    }
}
?>

<html lang="pt">

<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
	<title>Amazing Plans</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="styles/style.css">
	<link rel="stylesheet" href="styles/button.css">
	<link rel="stylesheet" href="styles/con-box.css">
</head>

<body>

	<!-- Container -->
	<div class="container">

		<!-- Map Boxs -->
		<div class="con-box">

			<?php if (isset($_GET['error'])) { ?>
				<p style="color: white; background-color: #e60000; border-radius: 3px; text-align: center; padding: 5px; width: 182px">
					<?php echo $_GET['error']; ?>
				</p>
				<br>
			<?php } ?>

			<form method="post">
				<div>
					<div class="label">
						<label><b>Pontos</b></label>
					</div>
					<input type="text" id="point" name="point" placeholder="Digite seu ponto">
				</div>
				<br>
				<div>
					<div class="label">
						<label><b>Cumpons</b></label>
					</div>
					<input type="text" id="cumpon" name="cumpon" placeholder="Digite seu cumpons">
				</div>
				<br>
				<div>
					<div class="label">
						<label><b>Saldo</b></label>
					</div>
					<input type="text" id="sald" name="sald" placeholder="Digite seu saldo">
				</div>
				<br>
				<div class="div">
					<input type="submit" value="Salvar" />
				</div>
			</form>
			<br>
			<!--button onclick="closeCurrentTab()">Cancelar</button-->
			<a href="update_pcsald_pt.php"><button>Alterar</button></a>
			<br><br>
			<a href="setting_pt.php"><button onclick="closeCurrentTab()">Cancelar</button></a>
		</div>

	</div>

	<!--script>
		function closeCurrentTab() {
    		window.close();
		}
	</script-->

</body>

</html>