<!DOCTYPE html>

<?php
session_start();
?>

<html lang="pt">

<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
    <title>Amazing Plans</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="styles/service.css">
    <link rel="stylesheet" href="styles/guide.css">
    <link rel="stylesheet" href="styles/gui-other.css">
</head>

<body>

    <div class="container">

        <!-- Container -->
        <div class="ser-box">

            <!-- Map Boxs -->
            <table>
                <tr>
                    <td>
                        <div class="box">
                            <a href="#"><img src="images/guides/5dd08b0cdef8b400084cd700_transparent.jpg" alt="" class="img"></a>
                            <p class="p" style="padding-top: 5px"><b>Luna Camila</b></p><br>
                            <p class="p">Idade: 40</p>
                            <p class="p">Barcelona - Espanha</p>
                            <p class="p">Idiomas: espanhol, ingês e francês.</p><br>
                            <p class="ppp">Currículo em Anexo</p><br>
                        </div>
                    </td>
                    <td>
                        <div class="box">
                            <a href="#"><img src="images/guides/5dd09b18def8b400084db3b4_transparent.jpg" alt="" class="img"></a>
                            <p class="p" style="padding-top: 5px"><b>Tiago Gomes</b></p><br>
                            <p class="p">Idade: 43</p>
                            <p class="p">São Paulo - Brasil</p>
                            <p class="p">Idiomas: português e ingês.</p><br>
                            <p class="ppp">Currículo em Anexo</p><br>
                        </div>
                    </td>
                    <td>
                        <div class="box">
                            <a href="#"><img src="images/guides/5dd086b8def8b400084c8042_transparent.jpg" alt="" class="img"></a>
                            <p class="p" style="padding-top: 5px"><b>Layla Abigail</b></p><br>
                            <p class="p">Idade: 35</p>
                            <p class="p">Chigaco - EUA</p>
                            <p class="p">Idiomas: inglês, espanhol e holandês</p><br>
                            <p class="ppp">Currículo em Anexo</p><br>
                        </div>
                    </td>
                    <td>
                        <div class="box">
                            <a href="#"><img src="images/guides/5dd0871fdef8b400084c8960_transparent.jpg" alt="" class="img"></a>
                            <p class="p" style="padding-top: 5px"><b>Victoria Silva</b></p><br>
                            <p class="p">Idade: 30</p>
                            <p class="p">Milão - Itália</p>
                            <p class="p">Idiomas: italiano, francês e alemão.</p><br>
                            <p class="ppp">Currículo em Anexo</p><br>
                        </div>
                    </td>
                </tr>

                <tr>
                    <td>
                        <div class="box">
                            <a href="#"><img src="images/guides/5e010ca57b1b300007ed3169_transparent.jpg" alt="" class="img"></a>
                            <p class="p" style="padding-top: 5px"><b>Caleb Steve</b></p><br>
                            <p class="p">Idade: 37</p>
                            <p class="p">Guadalajara - México</p>
                            <p class="p">Idiomas: espanhol e inglês.</p><br>
                            <p class="ppp">Currículo em Anexo</p><br>
                        </div>
                    </td>
                    <td>
                        <div class="box">
                            <a href="#"><img src="images/guides/5dd08bd8def8b400084ce513_transparent.jpg" alt="" class="img"></a>
                            <p class="p" style="padding-top: 5px"><b>Jimmy Michael</b></p><br>
                            <p class="p">Idade: 40</p>
                            <p class="p">Londres - Inglaterra</p>
                            <p class="p">Idiomas: inglês e alemão.</p><br>
                            <p class="ppp">Currículo em Anexo</p><br>
                        </div>
                    </td>
                    <td>
                        <div class="box">
                            <a href="#"><img src="images/guides/5dd08ac0def8b400084cd19c_transparent.jpg" alt="" class="img"></a>
                            <p class="p" style="padding-top: 5px"><b>Sakura Akida</b></p><br>
                            <p class="p">Idade: 35</p>
                            <p class="p">Tóquio - Japão</p>
                            <p class="p">Idiomas: japonesa e inglês.</p><br>
                            <p class="ppp">Currículo em Anexo</p><br>
                        </div>
                    </td>
                    <td>
                        <div class="box">
                            <a href="#"><img src="images/guides/5dd08a3fdef8b400084cc82f_transparent.jpg" alt="" class="img"></a>
                            <p class="p" style="padding-top: 5px"><b>Devonna Idna</b></p><br>
                            <p class="p">Idade: 32</p>
                            <p class="p">Bruxelas, Bélgica</p>
                            <p class="p">Idiomas: holandês, francês e inglês.</p><br>
                            <p class="ppp">Currículo em Anexo</p><br>
                        </div>
                    </td>
                </tr>

                <tr>
                    <td>
                        <div class="box">
                            <a href="#"><img src="images/guides/5dd0903ddef8b400084d2a29_transparent.jpg" alt="" class="img"></a>
                            <p class="p" style="padding-top: 5px"><b>Aleshka Gorky</b></p><br>
                            <p class="p">Idade: 33</p>
                            <p class="p">Moscou - Russia</p>
                            <p class="p">Idiomas: russo, alemão e inglês.</p><br>
                            <p class="ppp">Currículo em Anexo</p><br>
                        </div>
                    </td>
                    <td>
                        <div class="box">
                            <a href="#"><img src="images/guides/5dd0839ddef8b400084c2e1a_transparent.jpg" alt="" class="img"></a>
                            <p class="p" style="padding-top: 5px"><b>Hua Flag</b></p><br>
                            <p class="p">Idade: 39</p>
                            <p class="p">Xangai, China</p>
                            <p class="p">Idiomas: chinesa e inglês.</p><br>
                            <p class="ppp">Currículo em Anexo</p><br>
                        </div>
                    </td>
                    <td>
                        <div class="box">
                            <a href="#"><img src="images/guides/5dd0886cdef8b400084ca515_transparent.jpg" alt="" class="img"></a>
                            <p class="p" style="padding-top: 5px"><b>Micah Lee</b></p><br>
                            <p class="p">Idade: 42</p>
                            <p class="p">Brisbane - Austrália</p>
                            <p class="p">Idiomas: inglês e indonésia.</p><br>
                            <p class="ppp">Currículo em Anexo</p><br>
                        </div>
                    </td>
                    <td>
                        <div class="box">
                            <a href="#"><img src="images/guides/5e010e3d7b1b300007ef85e9_transparent.jpg" alt="" class="img"></a>
                            <p class="p" style="padding-top: 5px"><b>Omar Aabdar</b></p><br>
                            <p class="p">Idade: 37</p>
                            <p class="p">Dubai - EAU</p>
                            <p class="p">Idiomas: árabe, inglês e francês.</p><br>
                            <p class="ppp">Currículo em Anexo</p><br>
                        </div>
                    </td>
                </tr>

                <tr>
                    <td>
                        <div class="box">
                            <a href="#"><img src="images/guides/5e010b537b1b300007eb39c5_transparent.jpg" alt="" class="img"></a>
                            <p class="p" style="padding-top: 5px"><b>Willow Ava</b></p><br>
                            <p class="p">Idade: 38</p>
                            <p class="p">Auckland, Nova Zelândia</p>
                            <p class="p">Idiomas: inglês e Maori.</p><br>
                            <p class="ppp">Currículo em Anexo</p><br>
                        </div>
                    </td>
                    <td>
                        <div class="box">
                            <a href="#"><img src="images/guides/5e010aeb7b1b300007ea9e5d_transparent.jpg" alt="" class="img"></a>
                            <p class="p" style="padding-top: 5px"><b>Eero Rami</b></p><br>
                            <p class="p">Idade: 41</p>
                            <p class="p">Helsinki, Finlândia</p>
                            <p class="p">Idiomas: finlandesa e russo.</p><br>
                            <p class="ppp">Currículo em Anexo</p><br>
                        </div>
                    </td>
                    <td>
                        <div class="box">
                            <a href="#"><img src="images/guides/5e010d687b1b300007ee505f_transparent.jpg" alt="" class="img"></a>
                            <p class="p" style="padding-top: 5px"><b>Isa Jasmine</b></p><br>
                            <p class="p">Idade: 36</p>
                            <p class="p">Quezon, Filipinas</p>
                            <p class="p">Idiomas: filipino, inglês e malaia.</p><br>
                            <p class="ppp">Currículo em Anexo</p><br>
                        </div>
                    </td>
                    <td>
                        <div class="box">
                            <a href="#"><img src="images/guides/5e010b077b1b300007eac831_transparent.jpg" alt="" class="img"></a>
                            <p class="p" style="padding-top: 5px"><b>Atticus Ozias</b></p><br>
                            <p class="p">Idade: 40</p>
                            <p class="p">Atenas, Grécia</p>
                            <p class="p">Idiomas: grego, italiano e inglês.</p><br>
                            <p class="ppp">Currículo em Anexo</p><br>
                        </div>
                    </td>
                </tr>
            </table>

        </div>
    </div>

</body>

</html>
