<?php
session_start();

include("../connection.php");
error_reporting(0);

/*if ($_SERVER['REQUEST_METHOD'] == 'GET') {

    /*if(!isset($_GET['id'])){
        header("location: data.php");
        exit();
    }

    $id = $_SESSION['id'];

    $sql_0 = "SELECT * FROM users WHERE id='$id'";
    $result = $conn->query($sql_0);
    $row = $result->fetch_assoc();

    if(!$row){
        header("location: data.php");
        exit();
    }

    $fname = $row['fname'];
    $lname = $row['lname'];
    $email = $row['email'];
    $city = $row['city'];
    $state = $row['state'];
    $country = $row['country'];
}else{*/

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_SESSION['id'];

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $country = $_POST['country'];


    if (empty($fname) || empty($lname) || empty($email)) {
        header("Location: data_pt.php?error=Todos os campos são obrigatórios");
        exit();
    }

    $sql_1 = "UPDATE users SET fname='$fname', lname='$lname', email='$email', city='$city', state='$state', country='$country' WHERE id='$id'";
    $result = mysqli_query($conn, $sql_1);

    /*if (!$result) {
        header("Location: data_pt.php?error=Consulta inválida" . $conn->error);
        exit();
    }*/

    //$successMessage = "Client added correctly";

    if($result){
        header("Location: profile_pt.php?success=Atualização do cliente corretamente.");
        exit();
    }
}
?>