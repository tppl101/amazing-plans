<?php
session_start();

include("../connection.php");
error_reporting(0);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $email = $_SESSION['email'];

    $opassword = $_POST['opassword'];
    $password = $_POST['password'];

    if (empty($opassword) || empty($password)) {
        header("Location: password_pt.php?error=Todos os campos são obrigatórios");
        exit();
    }

    //$sql_0 = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    //$result = mysqli_query($conn, $sql_0);

    //if (mysqli_num_rows($result) === 1) {
        $sql_1 = "UPDATE users SET password='$password' WHERE email='$email'";
        $result = mysqli_query($conn, $sql_1);

        if($result){
            header("Location: profile_pt.php?success=Atualização do cliente corretamente.");
            exit();
        }
    //}
}
