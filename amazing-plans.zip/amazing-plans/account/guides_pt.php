<!DOCTYPE html>

<?php
session_start();
?>

<html lang="pt">

<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
	<title>Amazing Plans</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="styles/style.css">
	<link rel="stylesheet" href="styles/body.css">
	<link rel="stylesheet" href="styles/guide.css">
</head>

<body>

	<!-- Container -->
	<div class="container">

		<!-- Map Boxs -->
		<div class="map-box">
			<div class="box">
				<a href="#"><img src="images/guides/5dd08b0cdef8b400084cd700_transparent.jpg" alt="" class="img"></a>
				<p class="p" style="padding-top: 5px"><b>Luna Camila</b></p><br>
				<p class="p">Idade: 40</p>
				<p class="p">Barcelona - Espanha</p>
				<p class="p">Idiomas: espanhol, ingês e francês.</p><br>
				<p class="ppp">Currículo em Anexo</p><br>
			</div>
			<div style="margin-left: 15px" class="box">
				<a href="#"><img src="images/guides/5dd09b18def8b400084db3b4_transparent.jpg" alt="" class="img"></a>
				<p class="p" style="padding-top: 5px"><b>Tiago Gomes</b></p><br>
				<p class="p">Idade: 43</p>
				<p class="p">São Paulo - Brasil</p>
				<p class="p">Idiomas: português e ingês.</p><br>
				<p class="ppp">Currículo em Anexo</p><br>
			</div>
			<div style="margin-left: 15px" class="box">
				<a href="#"><img src="images/guides/5dd086b8def8b400084c8042_transparent.jpg" alt="" class="img"></a>
				<p class="p" style="padding-top: 5px"><b>Layla Abigail</b></p><br>
				<p class="p">Idade: 35</p>
				<p class="p">Chigaco - Estado Unidos</p>
				<p class="p">Idiomas: inglês, espanhol e holandês</p><br>
				<p class="ppp">Currículo em Anexo</p><br>
			</div>
			<div style="margin-left: 15px" class="box">
				<a href="#"><img src="images/guides/5dd0871fdef8b400084c8960_transparent.jpg" alt="" class="img"></a>
				<p class="p" style="padding-top: 5px"><b>Victoria Silva</b></p><br>
				<p class="p">Idade: 30</p>
				<p class="p">Milão - Itália</p>
				<p class="p">Idiomas: italiano, francês e alemão.</p><br>
				<p class="ppp">Currículo em Anexo</p><br>
			</div>
			<div style="margin-left: 15px" class="box">
				<a href="#"><img src="images/guides/5e010ca57b1b300007ed3169_transparent.jpg" alt="" class="img"></a>
				<p class="p" style="padding-top: 5px"><b>Caleb Steve</b></p><br>
				<p class="p">Idade: 37</p>
				<p class="p">Guadalajara - México</p>
				<p class="p">Idiomas: espanhol e inglês.</p><br>
				<p class="ppp">Currículo em Anexo</p><br>
			</div>
		</div>

	</div>

</body>

</html>