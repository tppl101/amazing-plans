<!DOCTYPE html>

<?php
session_start();

include("../connection.php");
error_reporting(0);

if ($_SERVER['REQUEST_METHOD'] == 'GET') {

	$user_id = $_SESSION['id'];

	$sql = "SELECT * FROM markers WHERE user_id='$user_id'";
	$result = mysqli_query($conn, $sql);
}
?>

<html lang="pt">

<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
	<title>Amazing Plans</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="styles/style.css">
	<link rel="stylesheet" href="styles/body.css">
	<link rel="stylesheet" href="styles/route.css">
</head>

<body>

	<!-- Container -->
	<div class="container">

		<!-- Map Boxs -->
		<div class="map-box">
			<!--
				Praia de Copacabana
			
				Elevador Lacerda</p>
						
				Ilha de Páscoa
				
				Fernando de Noronha</p>

				Baía de Matavai</p>
			-->

			<table>

				<?php
				while ($row = mysqli_fetch_assoc($result)) {
					$address = $row['address'];
					$name = $row['name'];
				?>
					<tr>
						<tb>
							<a href="<?php echo $address; ?>" target="_blank">
								<div class="r-box">
									<img src="images/icons/geo-alt-fill.svg" alt="">
								</div>
							</a>
							<p class="p-r"><?php echo $name; ?></p>
						</tb>
					</tr>
					<tr>
						<tb>
							<p style="color: #ffe6cc">....</p>
						</tb>
					</tr>
				<?php } ?>

			</table>
		</div>

	</div>

</body>

</html>