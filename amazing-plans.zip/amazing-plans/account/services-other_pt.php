<!DOCTYPE html>

<?php
session_start();
?>

<html lang="pt">

<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
    <title>Amazing Plans</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="styles/service.css">
    <link rel="stylesheet" href="styles/ser-other.css">
</head>

<body>

    <div class="container">

        <!-- Container -->
        <div class="ser-box">

            <!-- Map Boxs -->
            <table>
                <tr>
                    <td>
                        <a href="https://www.othon.com.br/"><img src="images/services/othon.jpg" alt="Othon" class="img"></a>
                        <p class="p">Hotel Rio Othon Palace</p>
                    </td>
                    <td>
                        <a href="https://www.belmond.com/"><img src="images/services/belmond.jpg" alt="Belmond" class="img"></a>
                        <p class="p">Copacabana Palace</p>
                    </td>
                    <td>
                        <a href="https://www.grandehoteldabarra.com.br/"><img src="images/services/barra.jpg" alt="Barra" class="img"></a>
                        <p class="p">Grande Hotel da Barra</p>
                    </td>
                    <td>
                        <a href="https://www.explora.com/"><img src="images/services/explora.jpg" alt="Explora" class="img"></a>
                        <p class="p">Explora Rapa Nui</p>
                    </td>
                </tr>

                <tr>
                    <td>
                        <a href="https://nayarahangaroa.com/"><img src="images/services/nayara.jpg" alt="Nayara" class="img"></a>
                        <p class="p">Nayara Hangaroa</p>
                    </td>
                    <td>
                        <a href="https://www.hilton.com/"><img src="images/services/hilton.jpg" alt="Hilton" class="img"></a>
                        <p class="p">DoubleTree by Hilton</p>
                    </td>
                    <td>
                        <a href="https://www.fairmont.com/"><img src="images/services/laurier.jpg" alt="Laurier" class="img"></a>
                        <p class="p">Fairmont Château Laurier</p>
                    </td>
                    <td>
                        <a href="https://nayarahangaroa.com/"><img src="images/services/titanic.jpg" alt="titanic" class="img"></a>
                        <p class="p">Titanic Hotel Liverpool</p>
                    </td>
                </tr>

                <tr>
                    <td>
                        <a href="https://www.danhotels.com/"><img src="images/services/dan.jpg" alt="Dan" class="img"></a>
                        <p class="p">Dan Panorama Tel-Aviv</p>
                    </td>
                    <td>
                        <a href="https://www.aquasis.com/"><img src="images/services/spa.jpg" alt="Spa" class="img"></a>
                        <p class="p">Aquasis De Luxe Resort</p>
                    </td>
                    <td>
                        <a href="http://www.tenseien.co.jp/"><img src="images/services/tenseien.jpg" alt="Tenseien" class="img"></a>
                        <p class="p">Tenseien</p>
                    </td>
                    <td>
                        <a href="https://dormy-hotels.com/"><img src="images/services/inn.jpg" alt="Inn" class="img"></a>
                        <p class="p">Dormy Inn Kochi</p>
                    </td>
                </tr>

                <tr>
                    <td>
                        <a href="https://www.decameron.com/"><img src="images/services/royal.jpg" alt="Royal" class="img"></a>
                        <p class="p">Royal Decameron Salinitas</p>
                    </td>
                    <td>
                        <a href="http://www.hotelxelena.com/"><img src="images/services/xelena.jpg" alt="Xelena" class="img"></a>
                        <p class="p">Xelena Hotel & Suites</p>
                    </td>
                    <td>
                        <a href="http://www.denalialaska.com/"><img src="images/services/bluffs.jpg" alt="Bluffs" class="img"></a>
                        <p class="p">Denali Bluffs</p>
                    </td>
                    <td>
                        <a href="https://movenpick.accor.com/"><img src="images/services/al.jpg" alt="Al" class="img"></a>
                        <p class="p">Al Bustan Rotana</p>
                    </td>
                </tr>
            </table>

        </div>
    </div>

</body>

</html>
