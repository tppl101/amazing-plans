<!DOCTYPE html>

<?php
session_start();

include("../connection.php");
error_reporting(0);

if ($_SERVER['REQUEST_METHOD'] == 'GET') {

    $user_id = $_SESSION['id'];

    $sql = "SELECT * FROM package WHERE user_id='$user_id'";
    $result = mysqli_query($conn, $sql);
}
?>

<html lang="pt">

<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
    <title>Amazing Plans</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="styles/body.css">
    <link rel="stylesheet" href="styles/list-box.css">
</head>

<body>

                <?php
                while ($row = mysqli_fetch_assoc($result)) {
                    $ps = $row['ps'];
                    $pv = $row['pv'];
                    $date = $row['date'];
                ?>
                    <tr>
                            <tb style="color: #804000">
                                <div>
                                    <p><?php echo $date; ?></p>
                                </div>
                                <div>
                                    <p><?php echo $ps; ?></p>
                                </div>
                                <div>
                                    <p><?php echo $pv; ?></p>
                                </div>
                                <div>
                                    <p><b>Pago</b></p>
                                </div>
                            </tb>
                    </tr>
                <?php } ?>

</body>

</html>