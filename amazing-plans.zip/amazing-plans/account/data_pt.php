<!DOCTYPE html>

<?php
session_start();

include("../connection.php");
error_reporting(0);

if ($_SERVER['REQUEST_METHOD'] == 'GET') {

	$id = $_SESSION['id'];

	$sql_0 = "SELECT * FROM users WHERE id='$id'";
	$result = mysqli_query($conn, $sql_0);
	$row = $result->fetch_assoc();

	$fname = $row['fname'];
	$lname = $row['lname'];
	$email = $row['email'];
	$city = $row['city'];
	$state = $row['state'];
	$country = $row['country'];
}
?>

<html lang="pt">

<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
	<title>Amazing Plans</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="styles/style.css">
	<link rel="stylesheet" href="styles/button.css">
	<link rel="stylesheet" href="styles/con-box.css">
</head>

<body>

	<!-- Container -->
	<div class="container">

		<!-- Map Boxs -->
		<div class="con-box">

			<?php if (isset($_GET['error'])) { ?>
				<p style="color: white; background-color: #e60000; border-radius: 3px; text-align: center; padding: 5px; width: 182px">
					<?php echo $_GET['error']; ?>
				</p>
				<br>
			<?php } ?>

			<form action="update.php" method="post">
				<div>
					<div class="label">
						<label><b>Nome</b></label>
					</div>
					<input type="text" id="fname" name="fname" value="<?php echo $fname; ?>" placeholder="Digite seu nome">
				</div>
				<br>
				<div>
					<div class="label">
						<label><b>Sobenome</b></label>
					</div>
					<input type="text" id="lname" name="lname" value="<?php echo $lname; ?>" placeholder="Digite seu sobrenome">
				</div>
				<br>
				<div>
					<div class="label">
						<label><b>Email</b></label>
					</div>
					<input type="text" id="email" name="email" value="<?php echo $email; ?>" placeholder="Digite seu email">
				</div>
				<br>
				<div>
					<div class="label">
						<label><b>Cidade</b></label>
					</div>
					<input type="text" id="city" name="city" value="<?php echo $city; ?>" placeholder="Digite sua cidade">
				</div>
				<br>
				<div>
					<div class="label">
						<label><b>Estado</b></label>
					</div>
					<input type="text" id="state" name="state" value="<?php echo $state; ?>" placeholder="Digite seu estado">
				</div>
				<br>
				<div>
					<div class="label">
						<label><b>País</b></label>
					</div>
					<input type="text" id="country" name="country" value="<?php echo $country; ?>" placeholder="Digite seu país">
				</div>
				<br>
				<div class="div">
					<input type="submit" value="Salvar" />
				</div>
			</form>
			<br>
			<!--button onclick="closeCurrentTab()">Cancelar</button-->
			<a href="profile_pt.php"><button onclick="closeCurrentTab()">Cancelar</button></a>
		</div>

	</div>

	<!--script>
		function closeCurrentTab() {
    		window.close();
		}
	</script-->

</body>

</html>