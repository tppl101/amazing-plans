<!DOCTYPE html>

<?php
session_start();
?>

<html lang="pt">

<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
	<title>Amazing Plans</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="styles/style.css">
	<link rel="stylesheet" href="styles/body.css">
	<link rel="stylesheet" href="styles/service.css">
</head>

<body>

	<!-- Container -->
	<div class="container">

		<!-- Map Boxs -->
		<div class="map-box">
			<div>
				<a href="https://www.othon.com.br/" target="_blank"><img src="images/services/othon.jpg" alt="Othon" class="img"></a>
				<p class="p">Hotel Rio Othon Palace</p>
			</div>
			<div style="margin-left: 15px">
				<a href="https://www.belmond.com/" target="_blank"><img src="images/services/belmond.jpg" alt="Belmond" class="img"></a>
				<p class="p">Copacabana Palace</p>
			</div>
			<div style="margin-left: 15px">
				<a href="https://www.grandehoteldabarra.com.br/" target="_blank"><img src="images/services/barra.jpg" alt="Barra" class="img"></a>
				<p class="p">Grande Hotel da Barra</p>
			</div>
			<div style="margin-left: 15px">
				<a href="https://www.explora.com/" target="_blank"><img src="images/services/explora.jpg" alt="Explora" class="img"></a>
				<p class="p">Explora Rapa Nui</p>
			</div>
			<div style="margin-left: 15px">
				<a href="https://nayarahangaroa.com/" target="_blank"><img src="images/services/nayara.jpg" alt="Nayara" class="img"></a>
				<p class="p">Nayara Hangaroa</p>
			</div>
		</div>

	</div>

</body>

</html>