<?php

session_start();

include("../connection.php");
error_reporting(0);

if ($_SERVER['REQUEST_METHOD'] == 'GET') {

    $user_id = $_SESSION['id'];

    $sql_0 = "SELECT * FROM pcsald WHERE user_id='$user_id'";
    $result = $conn->query($sql_0);
    $row = $result->fetch_assoc();
}

$point = $row['point'];
$cumpon = $row['cumpon'];
$sald = $row['sald'];

if ($sald >= 50) {

    $sald -= 50;
    $point += 50;

    $sql_1 = "UPDATE pcsald SET point='$point', sald='$sald' WHERE user_id='$user_id'";
    $result = mysqli_query($conn, $sql_1);

    if ($result) {

        $date = date('Y-m-d');
        $ps = "Pacote Simples";
        $pv = "- - - - - - - - - -";

        $query = "INSERT INTO package (ps, pv, date, user_id) VALUES ('$ps', '$pv', '$date', '$user_id')";
        mysqli_query($conn, $query);

        header("Location: card_pt.php?success=Compra do pacote com sucesso.");
        exit();
    }
    
} else {

    header("Location: card_pt.php?error=Saldo insuficiente para comprar pacote.");
    exit();

}

?>