<!DOCTYPE html>

<?php
session_start();

include("../connection.php");
error_reporting(0);

if ($_SERVER['REQUEST_METHOD'] == 'GET') {

    $user_id = $_SESSION['id'];

    $sql = "SELECT * FROM markers WHERE user_id='$user_id'";
    $result = mysqli_query($conn, $sql);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //$m_id = $_SESSION['m_id'];
    $name = $_POST['name'];

    $sql = "DELETE FROM markers WHERE name='$name'";
    mysqli_query($conn, $sql);

    header("Location: route_list_pt.php?delete=Está excluindo.");
    exit();
}
?>

<html lang="pt">

<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
    <title>Amazing Plans</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="styles/body.css">
    <link rel="stylesheet" href="styles/list-box.css">
</head>

<body>

    <!-- Container -->
    <div class="container">

        <!-- Map Boxs -->
        <div class="list-box">
            <h2 style="color: white">Lista de Rotas</h2>
            <br>

            <?php if (isset($_GET['delete'])) { ?>
                <p style="color: white; background-color: #e60000; border-radius: 3px; text-align: center; padding: 5px; width: 100%">
                    <?php echo $_GET['delete']; ?>
                </p>
                <br>
            <?php } ?>

            <table>

                <?php
                while ($row = mysqli_fetch_assoc($result)) {
                    $name = $row['name'];
                ?>
                    <tr>
                        <form method="post">
                            <tb>
                                <div>
                                    <input type="text" id="name" name="name" value="<?php echo $name; ?>" style="background-color: #ffe6cc; border: 0px; color: #804000" readonly>
                                </div>
                                <div>
                                    <input type="submit" value="Excluir">
                                </div>
                            </tb>
                        </form>
                    </tr>
                <?php } ?>

            </table>
        </div>

    </div>

</body>

</html>