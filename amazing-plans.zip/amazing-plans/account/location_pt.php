<!DOCTYPE html>

<?php
session_start();

include("../connection.php");
error_reporting(0);

if ($_SERVER['REQUEST_METHOD'] == 'GET') {

	$id = $_SESSION['id'];

	$sql_0 = "SELECT * FROM users WHERE id='$id'";
	$result = $conn->query($sql_0);
	$row = $result->fetch_assoc();

	$fname = $row['fname'];
	$lname = $row['lname'];
	$email = $row['email'];
	$city = $row['city'];
	$state = $row['state'];
	$country = $row['country'];
}

if (isset($_POST['submit-search'])) {
	$search = mysqli_real_escape_string($conn, $_POST['search']);
	$sql = "SELECT * FROM article WHERE a_title LIKE '%$search%'";

	$result = mysqli_query($conn, $sql);
	$queryr = mysqli_num_rows($result);

	if ($queryr > 0) {
		while ($row = mysqli_fetch_assoc($result)) {
			$link = $row['a_link'];
			header("Location: " . $link);
			exit();
		}
	} else {
		header("Location: location_pt.php?error=Não há resultados que correspondem à sua pesquisa.");
		exit();
	}
}
?>

<html lang="pt">

<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
	<title>Amazing Plans</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="styles/style.css">
	<link rel="stylesheet" href="styles/body.css">
</head>

<body>

	<!-- Container -->
	<div class="container">

		<!-- Section Left -->
		<div class="section-left">

			<div>

				<!-- Header Icon -->
				<a href="profile_pt.php">
					<div class="header-icon">
						<div class="header-svg">
							<img src="images/icons/person-circle.svg" alt="Personal" class="lager-icon">
						</div>
						<div class="header-p">
							<p><b><?php echo $fname, " ", $lname; ?></b></p>
						</div>
					</div>
				</a>

				<br>

				<!-- Section Icon -->
				<div>
					<a href="account_pt.php">
						<div class="section-icon">
							<div class="section-svg">
								<img src="images/icons/asterisk.svg" alt="Inicio" class="small-icon">
							</div>
							<div class="section-p">
								<p>Inicio</p>
							</div>
						</div>
					</a>
					<a href="tourism_pt.php">
						<div class="section-icon">
							<div class="section-svg">
								<img src="images/icons/person-walking.svg" alt="Guias Turisticos" class="small-icon">
							</div>
							<div class="section-p">
								<p>Guias Turisticos</p>
							</div>
						</div>
					</a>
					<a href="#">
						<div class="section-icon">
							<div class="section-svg">
								<img src="images/icons/geo-alt-fill.svg" alt="Localização" class="small-icon">
							</div>
							<div class="section-p">
								<p>Localização</p>
							</div>
						</div>
					</a>
					<a href="card_pt.php">
						<div class="section-icon">
							<div class="section-svg">
								<img src="images/icons/credit-card-2-back-fill.svg" alt="Carteira" class="small-icon">
							</div>
							<div class="section-p">
								<p>Carteira</p>
							</div>
						</div>
					</a>
				</div>

			</div>

			<!-- Footer Icon -->
			<div>
				<a href="setting_pt.php">
					<div class="footer-icon">
						<div class="footer-svg">
							<img src="images/icons/gear-fill.svg" alt="Configurar" class="small-icon">
						</div>
						<div class="footer-p">
							<p>Configurar</p>
						</div>
					</div>
				</a>
			</div>

		</div>

		<!-- Section Right -->
		<section class="section-right">

			<!-- header-logo -->
			<div class="header-logo">
				<div style="display: flex;">
					<div class="header-logo-svg">
						<img src="images/logo.png" alt="Amazing Plans" class="logo">
					</div>
					<div class="header-h1-p">
						<div>
							<h1>Amazing Plans</h1>
							<p><i>Planos e Rotas</i></p>
						</div>
					</div>
				</div>

				<form method="post">
					<div class="parallel">
						<div>
							<input type="text" id="search" name="search" placeholder="Digite sua pesquisa">
						</div>
						<div>
							<input type="submit" name="submit-search" value="Pesquisa">
						</div>
					</div>
				</form>

			</div>

			<!-- Newline 1 -->
			<div class="newline">

				<?php if (isset($_GET['error'])) { ?>
					<p style="color: white; background-color: #e60000; border-radius: 3px; text-align: center; padding: 5px;">
						<?php echo $_GET['error']; ?>
					</p>
					<br>
				<?php } ?>

				<div>
					<h2>Localização do mapa:</h2>
				</div>
				<div class="l-object">
					<object data="https://www.openstreetmap.org/export/embed.html?bbox=-75.14648437500001%2C-7.967043181022466%2C15.380859375000002%2C36.67259360368913&amp;layer=mapnik" type="text/html" class="location"></object>
				</div>
			</div>

		</section>

		<!-- Empity -->
		<div class="empity">
			<p>.</p>
		</div>

	</div>

</body>

</html>