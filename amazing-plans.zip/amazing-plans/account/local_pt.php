<!DOCTYPE html>

<?php
session_start();
?>

<html lang="pt">

<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
	<title>Amazing Plans</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="styles/style.css">
	<link rel="stylesheet" href="styles/button.css">
	<link rel="stylesheet" href="styles/con-box.css">
	<link rel="stylesheet" href="styles/link.css">
</head>

<body>

	<!-- Container -->
	<div class="container">

		<!-- Map Boxs -->
		<div class="con-box">

			<?php if (isset($_GET['error'])) { ?>
				<p style="color: white; background-color: #e60000; border-radius: 3px; text-align: center; padding: 5px; width: 182px">
					<?php echo $_GET['error']; ?>
				</p>
				<br>
			<?php } ?>

			<form action="addr.php" method="post">
				<div>
					<div class="label">
						<label><b>Nome - Tipo ou Cidade</b></label>
					</div>
					<input type="text" id="name" name="name" placeholder="Digite seu nome">
				</div>
				<br>
				<div>
					<div class="label">
						<label><b>Mapa - Link</b></label>
					</div>
					<textarea id="address" name="address" placeholder="Link - OSMaps"></textarea>
				</div>
				<br>
				<div>
					<input type="submit" value="Salvar">
				</div>
			</form>
			<br>
			<!--button onclick="closeCurrentTab()">Cancelar</button-->
			<a href="account_pt.php"><button onclick="closeCurrentTab()">Voltar</button></a>
			<p style="margin-top: 15px; color: white;">
				Clique aqui: <a class="a" style="width: 100%" href="https://www.openstreetmap.org/" target="_blank">OSMaps</a>
			</p>
			<p style="margin-top: 15px; color: white;">
				<a class="a" style="width: 100%" href="route_list_pt.php" target="_blank"><button>Lista de Rota</button></a>
			</p>
		</div>

	</div>

	<!--script>
		function closeCurrentTab() {
    		window.close();
		}
	</script-->

</body>

</html>