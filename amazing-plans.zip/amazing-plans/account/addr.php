<?php
session_start();

include("../connection.php");
error_reporting(0);

$user_id = $_SESSION['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $address = $_POST['address'];

    if (empty($name) || empty($address)) {
        header("Location: local_pt.php?error=Todos os campos são obrigatórios.");
        exit();
    }

    $query = "INSERT INTO markers (name, address, user_id) VALUES ('$name', '$address', $user_id)";
    $data = mysqli_query($conn, $query);

    if($data){
        header("Location: account_pt.php?success=Sua rota foi criada com sucesso.");
        exit();
    }
}
?>