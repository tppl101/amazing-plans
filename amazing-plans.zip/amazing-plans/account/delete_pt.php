<!DOCTYPE html>

<?php
session_start();

include("../connection.php");
error_reporting(0);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$email = $_POST['email'];
	$password = $_POST['password'];

	if (empty($email) || empty($password)) {
        header("Location: password_pt.php?error=Todos os campos são obrigatórios");
        exit();
    }

	$sql = "DELETE FROM users WHERE email='$email'";
	mysqli_query($conn, $sql);

	session_unset();
	session_destroy();
	header("Location: ../index_pt.php?error=Está excluindo sua conta.");
	exit();
}
?>

<html lang="pt">

<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
	<title>Amazing Plans</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="styles/style.css">
	<link rel="stylesheet" href="styles/button.css">
	<link rel="stylesheet" href="styles/con-box.css">
</head>

<body>

	<!-- Container -->
	<div class="container">

		<!-- Map Boxs -->
		<div class="con-box">

			<?php if (isset($_GET['error'])) { ?>
				<p style="color: white; background-color: #e60000; border-radius: 3px; text-align: center; padding: 5px; width: 182px">
					<?php echo $_GET['error']; ?>
				</p>
				<br>
			<?php } ?>

			<form method="post">
				<div>
					<div class="label">
						<label><b>Email</b></label>
					</div>
					<input type="email" id="email" name="email" placeholder="Digite seu email">
				</div>
				<br>
				<div>
					<div class="label">
						<label><b>Senha</b></label>
					</div>
					<input type="password" id="password" name="password" placeholder="Digite sua senha">
				</div>
				<br>
				<div class="div">
					<input type="submit" value="Excluir" />
				</div>
			</form>
			<br>
			<a href="setting_pt.php"><button>Voltar</button></a>
		</div>

	</div>

</body>

</html>