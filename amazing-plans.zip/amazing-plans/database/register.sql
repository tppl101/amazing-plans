-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2024 at 04:29 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `a_id` bigint(20) NOT NULL,
  `a_title` varchar(100) NOT NULL,
  `a_link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`a_id`, `a_title`, `a_link`) VALUES
(1, 'Inicio', 'account_pt.php'),
(2, 'Rotas', 'account_pt.php'),
(3, 'Serviços', 'account_pt.php'),
(4, 'Criar rota', 'local_pt.php'),
(5, 'Guias Turisticos', 'tourism_pt.php'),
(6, 'Guias', 'tourism_pt.php'),
(7, 'Localização', 'location_pt.php'),
(8, 'Carteira', 'card_pt.php'),
(9, 'Configurar', 'setting_pt.php'),
(10, 'Ajuda', 'setting_pt.php'),
(11, 'Insira os pontos', 'pcsald_pt.php'),
(12, 'Insirir cupons', 'pcsald_pt.php'),
(13, 'Insira o saldo', 'pcsald_pt.php'),
(14, 'Alterar os pontos', 'update_pcsald_pt.php'),
(15, 'Alterar cupons', 'update_pcsald_pt.php'),
(16, 'Alterar o saldo', 'update_pcsald_pt.php'),
(17, 'Excluir minha conta', 'setting_pt.php'),
(18, 'Pessoal', 'profile_pt.php'),
(19, 'Fatura', 'profile_pt.php'),
(20, 'Alterar senha', 'password_pt.php'),
(21, 'Alterar dados', 'data_pt.php');

-- --------------------------------------------------------

--
-- Table structure for table `markers`
--

CREATE TABLE `markers` (
  `m_id` bigint(20) NOT NULL,
  `name` varchar(250) NOT NULL,
  `address` text NOT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `markers`
--

INSERT INTO `markers` (`m_id`, `name`, `address`, `user_id`) VALUES
(9, 'Roma, Italia', 'https://www.openstreetmap.org/?mlat=41.870&mlon=12.437#map=6/41.878/12.437', 5);

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `k_id` bigint(20) NOT NULL,
  `ps` varchar(50) NOT NULL,
  `pv` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `package`
--

INSERT INTO `package` (`k_id`, `ps`, `pv`, `date`, `user_id`) VALUES
(10, 'Pacote Simples', '- - - - - - - - - -', '2024-05-22', 5),
(11, '- - - - - - - - - - - - - -', 'Pacote VIP', '2024-05-22', 5),
(12, '- - - - - - - - - - - - - -', 'Pacote VIP', '2024-05-22', 5);

-- --------------------------------------------------------

--
-- Table structure for table `pcsald`
--

CREATE TABLE `pcsald` (
  `p_id` bigint(20) NOT NULL,
  `point` int(11) NOT NULL,
  `cumpon` int(11) NOT NULL,
  `sald` float NOT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pcsald`
--

INSERT INTO `pcsald` (`p_id`, `point`, `cumpon`, `sald`, `user_id`) VALUES
(3, 526, 14, 430, 5);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(20) NOT NULL,
  `birth` date NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `password`, `birth`, `city`, `state`, `country`) VALUES
(3, 'John', 'Steve', 'john@pm.me', '12345', '1995-02-20', '', '', ''),
(5, 'David', 'Lee', 'lee@mail.org', '34567', '1987-03-04', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `markers`
--
ALTER TABLE `markers`
  ADD PRIMARY KEY (`m_id`),
  ADD KEY `u_markers` (`user_id`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`k_id`),
  ADD KEY `u_package` (`user_id`);

--
-- Indexes for table `pcsald`
--
ALTER TABLE `pcsald`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `u_pcsald` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `a_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `markers`
--
ALTER TABLE `markers`
  MODIFY `m_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `package`
--
ALTER TABLE `package`
  MODIFY `k_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `pcsald`
--
ALTER TABLE `pcsald`
  MODIFY `p_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `markers`
--
ALTER TABLE `markers`
  ADD CONSTRAINT `u_markers` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `package`
--
ALTER TABLE `package`
  ADD CONSTRAINT `u_package` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `pcsald`
--
ALTER TABLE `pcsald`
  ADD CONSTRAINT `u_pcsald` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
