<?php
include("connection.php");
error_reporting(0);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $birth = $_POST['birth'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $country = $_POST['country'];
    $check = $_POST['check'];

    if (empty($fname) || empty($lname) || empty($email) || empty($birth)) {
        header("Location: signup_pt.php?error=Todos os campos são obrigatórios.");
        exit();
    }

    if (empty($check)) {
        header("Location: signup_pt.php?error=A caixa de seleção é obrigatória.");
        exit();
    }

    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0){
        header("Location: signup_pt.php?error=O email foi recebido, tente outro.");
        exit();
    }else{
        $query = "INSERT INTO users (fname, lname, email, password, birth, city, state, country) VALUES ('$fname', '$lname', '$email', '$password', '$birth', '$city', '$state', '$country')";
        $data = mysqli_query($conn, $query);

        header("Location: signup_pt.php?success=Sua conta foi criada com sucesso.");
        exit();
    }
}
