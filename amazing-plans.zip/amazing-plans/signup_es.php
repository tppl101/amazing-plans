<!DOCTYPE html>

<html>

<head>
	<meta charset="utf-8" />
	<link rel="shortcut icon" href="images/logo.png" type="image/x-icon" />
	<title>Amazing Plans</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<link rel="stylesheet" href="styles/style.css" />
	<link rel="stylesheet" href="styles/signup.css" />
</head>

<body background="images/background.jpg" style="background-size: cover;">
	<div class="center">
		<div class="logo">
			<img src="images/logo.png" alt="Amazing Plans" />
			<h1>Amazing Plans</h1>
			<p><i>Planes y Rutas</i></p>
		</div>
		<div class="account">

			<?php if (isset($_GET['error'])) { ?>
				<p style="color: white; background-color: #e60000; border-radius: 3px; text-align: center; padding: 5px;">
					<?php echo $_GET['error']; ?>
				</p>
				<br>
			<?php } ?>

			<form action="data_es.php" method="post">
				<div class="parallel">
					<div class="size">
						<label><b>Nombre<font style="color: #994d00">*</font></b></label>
						<input type="text" id="fname" name="fname" placeholder="Ingresa tu nombre">
					</div>
					<div class="size">
						<label><b>Apellido<font style="color: #994d00">*</font></b></label>
						<input type="text" id="lname" name="lname" placeholder="Ingresa tu apellido">
					</div>
				</div>
				<div class="parallel">
					<div class="size" style="margin-top: 5px">
						<label><b>Email<font style="color: #994d00">*</font></b></label>
						<input type="email" id="email" name="email" placeholder="Ingresa tu email">
					</div>
					<div class="size" style="margin-top: 5px">
						<label><b>Contraseña<font style="color: #994d00">*</font></b></label>
						<input type="password" id="password" name="password" placeholder="Ingresa tu contraseña">
					</div>
				</div>
				<div class="parallel">
					<div class="size" style="margin-top: 5px">
						<label><b>Nacimiento<font style="color: #994d00">*</font></b></label>
						<input type="date" id="birth" name="birth">
					</div>
					<div class="size" style="margin-top: 5px">
						<label><b>Ciudad</b></label>
						<input type="text" id="city" name="city" placeholder="Ingresa tu ciudad" />
					</div>
				</div>
				<div class="parallel">
					<div class="size" style="margin-top: 5px">
						<label><b>Estado</b></label>
						<input type="text" id="state" name="state" placeholder="Ingresa tu estado" />
					</div>
					<div class="size" style="margin-top: 5px">
						<label><b>País</b></label>
						<input type="text" id="country" name="country" placeholder="Ingresa tu país" />
					</div>
				</div>
				<div class="check">
					<input type="checkbox" id="check" name="check" value="check">
					<p>He leído y acepto los términos de servicio y privacidad de la aplicación.<font style="color: #994d00">*</font>
					</p>
				</div>
				<div class="div">
					<a href="index_es.php">
						<p>¿Ya tienes una cuenta? Acceso</p>
					</a>
					<input type="submit" value="Inscribirse" />
				</div>
			</form>
		</div>
	</div>
</body>

</html>