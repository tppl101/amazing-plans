<?php
session_start();
include("connection.php");
error_reporting(0);

if (isset($_POST['email']) && isset($_POST['password'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        header("Location: index_pt.php?error=Todos os campos são obrigatórios.");
        exit();
    }

    $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);

        $_SESSION['fname']   = $row['fname'];
        $_SESSION['lname']   = $row['lname'];
        $_SESSION['email']   = $row['email'];
        $_SESSION['birth']   = $row['birth'];
        $_SESSION['city']    = $row['city'];
        $_SESSION['state']   = $row['state'];
        $_SESSION['country'] = $row['country'];
        $_SESSION['id']      = $row['id'];

        $id = $row['id'];

        // Fetch markers
        $sql = "SELECT * FROM markers WHERE user_id='$id'";
        $result = mysqli_query($conn, $sql);
        if ($marker = mysqli_fetch_assoc($result)) {
            $_SESSION['name']    = $marker['name'];
            $_SESSION['address'] = $marker['address'];
            $_SESSION['m_id']    = $marker['m_id'];
        }

        header("Location: account/account_pt.php");
        exit();
    } else {
        header("Location: index_pt.php?error=Senha ou email incorreto.");
        exit();
    }
}
?>
