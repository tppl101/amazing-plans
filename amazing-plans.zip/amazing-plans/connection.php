<?php
    $servername = "localhost";
    $username = "phpmyadmin";
    $password = "hLNi4O6w8rYH!";
    $dbname = "register";

    $conn = mysqli_connect($servername, $username, $password, $dbname);

    if($conn){
        //echo "Connection succesfully established...";
    }else{
        //echo "An error ocurred with the query...".mysqli_connect_error;
    }
?>