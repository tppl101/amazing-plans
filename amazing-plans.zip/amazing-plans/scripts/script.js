function redirectToPage() {
    var selectedLanguage = document.getElementById("idioma").value;
    var redirectUrl;

    switch (selectedLanguage) {
    case "pt":
        redirectUrl = "index_pt.php";
        break;
    case "en":
        redirectUrl = "index_en.php";
        break;
    case "es":
        redirectUrl = "index_es.php";
        break;
    default:
        redirectUrl = "index_en.php";
    }

    window.location.href = redirectUrl;
}
