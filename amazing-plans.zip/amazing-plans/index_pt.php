<!DOCTYPE html>

<html>

<head>
	<meta charset="utf-8" />
	<link rel="shortcut icon" href="images/logo.png" type="image/x-icon" />
	<title>Amazing Plans</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<link rel="stylesheet" href="styles/style.css" />
	<link rel="stylesheet" href="styles/body.css" />
</head>

<body background="images/background.jpg" style="background-size: cover;">
	<div class="center">
		<div class="logo">
			<img src="images/logo.png" alt="Amazing Plans" />
			<h1>Amazing Plans</h1>
			<p><i>Planos e Rotas</i></p>
		</div>
		<div class="account">

			<?php if (isset($_GET['error'])) { ?>
				<p style="color: white; background-color: #e60000; border-radius: 3px; text-align: center; padding: 5px;">
					<?php echo $_GET['error']; ?>
				</p>
				<br>
			<?php } ?>

			<form action="login.php" method="post">
				<div class="parallel">
					<div class="size">
						<label><b>Email</b></label>
						<input type="email" id="email" name="email" placeholder="Digite seu email">
					</div>
					<div class="size">
						<label><b>Senha</b></label>
						<input type="password" id="password" name="password" placeholder="Digite sua senha">
					</div>
				</div>
				<div class="div">
					<a href="signup_pt.php">
						<p>Ainda não tem uma conta? Cadastre-se</p>
					</a>
					<input type="submit" value="Login">
				</div>
			</form>
		</div>
		<div class="select">
			<form onsubmit="redirectToPage(); return false;">
				<label for="idioma"><b>Selecione o idioma:<b></label>
				<select name="idioma" id="idioma">
					<option value="en">English</option>
					<option value="pt">Português</option>
					<option value="es">Español</option>
				</select>
				<input type="submit" value="Alterar">
			</form>
		</div>
	</div>

	<script>
		function redirectToPage() {
			var selectedLanguage = document.getElementById("idioma").value;
			var redirectUrl;

			switch (selectedLanguage) {
				case "pt":
					redirectUrl = "index_pt.php";
					break;
				case "en":
					redirectUrl = "index_en.php";
					break;
				case "es":
					redirectUrl = "index_es.php";
					break;
				default:
					redirectUrl = "index_en.php";
			}

			window.location.href = redirectUrl;
		}
	</script>
</body>

</html>