<!DOCTYPE html>

<html>

<head>
	<meta charset="utf-8" />
	<link rel="shortcut icon" href="images/logo.png" type="image/x-icon" />
	<title>Amazing Plans</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<link rel="stylesheet" href="styles/style.css" />
	<link rel="stylesheet" href="styles/signup.css" />
</head>

<body background="images/background.jpg" style="background-size: cover;">
	<div class="center">
		<div class="logo">
			<img src="images/logo.png" alt="Amazing Plans" />
			<h1>Amazing Plans</h1>
			<p><i>Planos e Rotas</i></p>
		</div>
		<div class="account">

			<?php if (isset($_GET['error'])) { ?>
				<p style="color: white; background-color: #e60000; border-radius: 3px; text-align: center; padding: 5px;">
					<?php echo $_GET['error']; ?>
				</p>
				<br>
			<?php } ?>
			<?php if (isset($_GET['success'])) { ?>
				<p style="color: white; background-color: green; border-radius: 3px; text-align: center; padding: 5px;">
					<?php echo $_GET['success']; ?>
				</p>
				<br>
			<?php } ?>

			<form action="data.php" method="post">
				<div class="parallel">
					<div class="size">
						<label><b>Nome<font style="color: #994d00">*</font></b></label>
						<input type="text" id="fname" name="fname" placeholder="Digite seu nome">
					</div>
					<div class="size">
						<label><b>Sobrenome<font style="color: #994d00">*</font></b></label>
						<input type="text" id="lname" name="lname" placeholder="Digite seu sobrenome">
					</div>
				</div>
				<div class="parallel">
					<div class="size" style="margin-top: 5px">
						<label><b>Email<font style="color: #994d00">*</font></b></label>
						<input type="email" id="email" name="email" placeholder="Digite seu email">
					</div>
					<div class="size" style="margin-top: 5px">
						<label><b>Senha<font style="color: #994d00">*</font></b></label>
						<input type="password" id="password" name="password" placeholder="Digite sua senha">
					</div>
				</div>
				<div class="parallel">
					<div class="size" style="margin-top: 5px">
						<label><b>Nascimento<font style="color: #994d00">*</font></b></label>
						<input type="date" id="birth" name="birth">
					</div>
					<div class="size" style="margin-top: 5px">
						<label><b>Cidade</b></label>
						<input type="text" id="city" name="city" placeholder="Digite sua cidade" />
					</div>
				</div>
				<div class="parallel">
					<div class="size" style="margin-top: 5px">
						<label><b>Estado</b></label>
						<input type="text" id="state" name="state" placeholder="Digite seu estado" />
					</div>
					<div class="size" style="margin-top: 5px">
						<label><b>País</b></label>
						<input type="text" id="country" name="country" placeholder="Digite seu país" />
					</div>
				</div>
				<div class="check">
					<input type="checkbox" id="check" name="check" value="check">
					<p>Li e concordo com os termos de serviço e privacidade do aplicativo.<font style="color: #994d00">*</font>
					</p>
				</div>
				<div class="div">
					<a href="index_pt.php">
						<p>Já tem uma conta? Faça login</p>
					</a>
					<input type="submit" value="Cadastre-se" />
				</div>
			</form>
		</div>
	</div>
</body>

</html>